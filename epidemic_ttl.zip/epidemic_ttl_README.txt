Sample scenario of testing the effect of Time to Live (TTL) to Epidemic 
routing protocol's performance. The package contains also the resulting 
report files, so you can use this to see if you managed to install and run 
the ONE properly.

The epidemic_ttl_test.txt settings file assumes that you have the 
"default_settings.txt" from the original ONE 1.0 distribution package. If you 
run ONE with the given config file with the command
one -b epidemic_ttl_test.txt 3
you should end up with three report files in the epidemic_ttl_test directory.
The contents of the files should be identical to the ones in this zip file.


Contact:
ari.keranen@netlab.tkk.fi
For questions about the ONE, please use the mailing list at 
https://www.netlab.tkk.fi/mailman/listinfo/theone